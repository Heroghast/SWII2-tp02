﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SW2TP02.DAO {
    public class UsuariosDAO {
    }
}